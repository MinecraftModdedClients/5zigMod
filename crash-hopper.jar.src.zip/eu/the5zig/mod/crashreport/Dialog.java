package eu.the5zig.mod.crashreport;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Dialog
  extends JFrame
{
  public Dialog(final String crashLog)
  {
    try
    {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch (Exception localException) {}
    setSize(460, 150);
    setLayout(null);
    setResizable(false);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(3);
    setTitle("Minecraft has crashed!");
    requestFocus();
    setVisible(true);
    
    JLabel title = new JLabel("<html><center>Oops, looks like the game crashed<br>due to the 5zig Mod!</center></html>", 0);
    title.setBounds(5, 5, 450, 50);
    title.setFont(new Font("Verdana", 0, 18));
    add(title);
    
    JLabel subtitle = new JLabel("Do you want to report the crash and help the author fix the problem?");
    subtitle.setBounds(5, 55, 490, 20);
    subtitle.setFont(new Font("Verdana", 0, 12));
    add(subtitle);
    
    JButton yes = new JButton("Yes");
    yes.setBounds(70, 90, 100, 25);
    yes.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        Dialog.this.setVisible(false);
        ReportService.report(crashLog);
      }
    });
    add(yes);
    
    JButton no = new JButton("No");
    no.setBounds(175, 90, 100, 25);
    no.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        System.exit(0);
      }
    });
    add(no);
    
    JButton review = new JButton("Review");
    review.setBounds(280, 90, 100, 25);
    review.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        Dialog.this.dispose();
        new Frame(crashLog);
      }
    });
    add(review);
  }
  
  public static void main(String[] args)
  {
    SwingUtilities.invokeLater(new Runnable()
    {
      public void run()
      {
        new Dialog("");
      }
    });
  }
}
