package eu.the5zig.mod.crashreport;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import javax.swing.SwingUtilities;

public class Main
{
  public static void main(String[] args)
  {
    if (args.length != 2) {
      throw new IllegalArgumentException(Arrays.toString(args));
    }
    boolean autoReport = Boolean.parseBoolean(args[0]);
    File crashFile = new File(args[1]);
    if (!crashFile.exists()) {
      throw new IllegalArgumentException("File \"" + crashFile.getAbsolutePath() + "\" does not exist!");
    }
    StringBuilder stringBuilder = new StringBuilder();
    BufferedReader reader = null;
    try
    {
      reader = new BufferedReader(new InputStreamReader(new FileInputStream(crashFile), "UTF-8"));
      String line;
      while ((line = reader.readLine()) != null) {
        stringBuilder.append(line).append("\n");
      }
      if (reader != null) {
        try
        {
          reader.close();
        }
        catch (IOException e)
        {
          e.printStackTrace();
        }
      }
      crashLog = stringBuilder.toString();
    }
    catch (IOException e)
    {
      throw new RuntimeException(e);
    }
    finally
    {
      if (reader != null) {
        try
        {
          reader.close();
        }
        catch (IOException e)
        {
          e.printStackTrace();
        }
      }
    }
    String crashLog;
    if (autoReport) {
      ReportService.report(crashLog);
    } else {
      SwingUtilities.invokeLater(new Runnable()
      {
        public void run()
        {
          new Dialog(this.val$crashLog);
        }
      });
    }
  }
}
