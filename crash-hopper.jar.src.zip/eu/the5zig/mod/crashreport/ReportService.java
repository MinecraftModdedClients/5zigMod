package eu.the5zig.mod.crashreport;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class ReportService
{
  private static final String REPORT_URL = "http://5zig.eu/api/report";
  private static final Gson gson = new Gson();
  
  public static void report(String crashLog)
  {
    try
    {
      HttpURLConnection connection = (HttpURLConnection)new URL("http://5zig.eu/api/report").openConnection();
      connection.setDoInput(true);
      connection.setDoOutput(true);
      connection.setRequestMethod("POST");
      connection.setRequestProperty("Accept", "application/json");
      connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
      
      Payload payload = new Payload("the5zigmod", crashLog);
      String json = gson.toJson(payload);
      
      OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
      writer.write(json);
      writer.close();
      
      StringBuilder jsonString = new StringBuilder();
      InputStream inputStream;
      InputStream inputStream;
      if (connection.getResponseCode() == 200) {
        inputStream = connection.getInputStream();
      } else {
        inputStream = connection.getErrorStream();
      }
      BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
      String line;
      while ((line = br.readLine()) != null) {
        jsonString.append(line).append("\n");
      }
      br.close();
      System.out.println("Response: " + jsonString.toString());
      
      connection.disconnect();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    System.exit(0);
  }
  
  private static class Payload
  {
    private String product;
    private String crashLog;
    
    public Payload(String product, String crashLog)
    {
      this.product = product;
      this.crashLog = crashLog;
    }
  }
}
