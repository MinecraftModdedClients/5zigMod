package eu.the5zig.mod.crashreport;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Frame
  extends JFrame
{
  private final String crashLog;
  
  public Frame(final String crashLog)
  {
    this.crashLog = crashLog;
    
    setResizable(false);
    setSize(900, 600);
    setLayout(null);
    setLocationRelativeTo(null);
    setTitle("Minecraft has crashed!");
    setDefaultCloseOperation(3);
    
    JTextArea view = new JTextArea(crashLog);
    view.setEditable(false);
    JScrollPane textArea = new JScrollPane(view);
    textArea.setBounds(5, 5, 885, 530);
    add(textArea);
    
    JButton cancelButton = new JButton("Cancel");
    cancelButton.setBounds(360, 540, 95, 26);
    cancelButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        System.exit(0);
      }
    });
    add(cancelButton);
    
    JButton reportButton = new JButton("Send Report");
    reportButton.setBounds(465, 540, 95, 26);
    reportButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        Frame.this.setVisible(false);
        ReportService.report(crashLog);
      }
    });
    add(reportButton);
    
    setVisible(true);
  }
  
  public static void main(String[] args)
  {
    new Frame("Test");
  }
}
